package com.example.weatherapplication;

import android.annotation.SuppressLint;
import android.util.Log;

import org.json.JSONException;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

// api에서 날씨 데이터를 가져와
public class WeatherData{
    String TMP = ""; // 1시간 기온
    String TMN = ""; // 최저 기온
    String TMX = ""; // 최고 기온
    String POP = ""; // 강수 확률
    String PCP = ""; // 1시간 강수량
    String SKY = ""; // 하늘 상태
    String PTY = ""; // 강수 형태
    String resultCode = ""; // 결과 코드

    int state = 0;
    // 0: 오늘 날짜, 현재 시간의 날씨를 저장
    // 1: 어제 23시의 데이터를 불러와 오늘의 최고기온, 최저기온을 저장

    @SuppressLint("LongLogTag")
    public void func(String x, String y) throws IOException, JSONException {

        // 현재 날짜와 시간 구하기
        long mNow = System.currentTimeMillis();
        Date mReDate = new Date(mNow);

        SimpleDateFormat mFormatYDM = new SimpleDateFormat("yyyyMMdd"); //현재 날짜 데이터
        String base_date = mFormatYDM.format(mReDate);
        String base_date2 = base_date;

        SimpleDateFormat mFormatTime = new SimpleDateFormat("HHmm");    // 현재 시간 대
        int currentTime = Integer.parseInt(mFormatTime.format(mReDate));
        String base_time = "2300";

        // 가장 최근의 데이터 발표시각. 2시 이전일 경우 전날의 23시 데이터를 불러옴
        if (currentTime < 215) {
            Calendar calendar = new GregorianCalendar(Locale.KOREA);
            calendar.add(Calendar.DATE, -1);
            base_date = mFormatYDM.format(calendar.getTime());
        }
        else if (currentTime < 515) base_time = "0200";
        else if (currentTime < 815) base_time = "0500";
        else if (currentTime < 1115) base_time = "0800";
        else if (currentTime < 1415) base_time = "1100";
        else if (currentTime < 1715) base_time = "1400";
        else if (currentTime < 2015) base_time = "1700";
        else if (currentTime < 2315) base_time = "2000";

        // api 연결 후 값 받아오기, 오늘날짜
        UrlConnect urlConnect = new UrlConnect();
        String result = urlConnect.seturl(base_date, base_time, x, y);

        ParseData parseData = new ParseData();
        resultCode = parseData.parse(result, state); // state = 오늘 날짜(0)임을 알려줌
        state = 1;

        // 어제 날짜를 불러와 최고, 최저 기온 값 저장. 이미 전날 데이터를 불러왔을 경우 날짜를 이전 날짜로 바꾸지 않음
        String yesterday = base_date;
        if (base_date.equals(base_date2)&& (currentTime < 2300)) {
            Calendar calendar = new GregorianCalendar(Locale.KOREA);
            calendar.add(Calendar.DATE, -1);

            SimpleDateFormat mFormatYDM_Y = new SimpleDateFormat("yyyyMMdd"); //현재 날짜 데이터
            yesterday = mFormatYDM_Y.format(calendar.getTime());
        }

        String currentBase;
        if(currentTime >= 2300 && currentTime < 2315)
            currentBase = "2000";
        else
            currentBase = "2300";

        String resultYesterday = urlConnect.seturl(yesterday, currentBase, x, y);
        resultCode = parseData.parse(resultYesterday, state); // state = 어제 날짜(1)임을 알려줌
        state = 0;

        // ParseData 를 이용해 추출한 값들을 저장
        TMP = parseData.getTMP();
        TMN = parseData.getTMN();
        TMX = parseData.getTMX();
        POP = parseData.getPOP();
        PCP = parseData.getPCP();
        SKY = parseData.getSKY();
        PTY = parseData.getPTY();

        Log.i("{TMP, TMN, TMX, POP, PCP, SKY, PTY} ", TMP + ", " + TMN + ", " + TMX + ", " + POP + ", " + PCP + ", " + SKY + ", " + PTY);
    }

    public String getWeather() {
        String ret = TMP + "," + TMN + "," + TMX + "," + POP + "," + PCP + "," + SKY + "," + PTY;
        return ret;
    }
    public String getResultCode() {
        return resultCode;
    }
}
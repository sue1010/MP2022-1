package com.example.weatherapplication;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class weather_rec extends AppCompatActivity {

    TextView textView; // 지역 이름
    TextView some_id2; // 하늘 상태
    TextView textView3; // 기온
    TextView textView5; // 강수확률
    TextView textView7; // 강수량

    ImageButton weatherButton; // 날씨
    ImageButton imageButton3; // 옷 추천
    ImageButton imageButton4; // 음식 추천
    ImageButton GPS; // 위치 재설정

    Utils utils;

    public static Activity activity;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        some_id2 = findViewById(R.id.some_id2);
        textView3 = findViewById(R.id.textView3);
        textView5 = findViewById(R.id.textView5);
        textView7 = findViewById(R.id.textView7);

        weatherButton = findViewById(R.id.weather);
        imageButton3 = findViewById(R.id.imageButton3);
        imageButton4 = findViewById(R.id.imageButton4);
        GPS = findViewById(R.id.gps);

        // 받은 인텐트로 지역과 날씨 정보 받아옴
        Intent get = getIntent();
        String weatherStr = get.getStringExtra("weather");
        String location = get.getStringExtra("location");
        utils = new Utils(weatherStr);

        // 현재 시간 대 (분 단위는 00)
        long mNow = System.currentTimeMillis();
        Date mReDate = new Date(mNow);

        SimpleDateFormat mFormatTime = new SimpleDateFormat("HH00");
        String currentTime = mFormatTime.format(mReDate);

        int cur = Integer.parseInt(currentTime);
        if(cur >= 2000 || cur < 500){
            ImageView imageNight = findViewById(R.id.sunny);
            imageNight.setImageDrawable(getDrawable(R.drawable.night));

            ImageView imageMoon = findViewById(R.id.sun);
            imageMoon.setImageDrawable(getDrawable(R.drawable.moon));
        }

        // utils.getSKY()로 하늘 상태를 받아와 이미지뷰 설정
        if(utils.getSKY().equals("흐림")){
            // 날씨 아이콘
            ImageView imageblur =findViewById(R.id.sun);
            imageblur.setImageDrawable(getDrawable(R.drawable.cloud));

            //날씨 배경
            ImageView imageblurbackground = findViewById(R.id.sunny);
            imageblurbackground.setImageDrawable(getDrawable(R.drawable.rainy));

        } else if(utils.getSKY().equals("구름 많음")){
            // 날씨 아이콘
            ImageView imagecloud =findViewById(R.id.sun);
            imagecloud.setImageDrawable(getDrawable(R.drawable.cloud));
        }

        // 비, 눈 여부에 따라 아이콘/배경 설정
        if(utils.getPTY().equals("비")){
            // 아이콘
            ImageView rain = findViewById(R.id.sun);
            rain.setImageDrawable(getDrawable(R.drawable.rain));

        }
        else if(utils.getPTY().equals("비/눈") || utils.getPTY().equals("눈")){
            // 배경
            ImageView imagerainysnowy = findViewById(R.id.sunny);
            imagerainysnowy.setImageDrawable(getDrawable(R.drawable.snowy));

            // 아이콘
            ImageView snowy = findViewById(R.id.sun);
            snowy.setImageDrawable(getDrawable(R.drawable.snow));
        }
        else if(utils.getPTY().equals("소나기")){
            ImageView imageshortrain = findViewById(R.id.sun);
            imageshortrain.setImageDrawable(getDrawable(R.drawable.rain));
        }


        // 날씨 정보 텍스트
        textView.setText(location);
        some_id2.setText(utils.getSKY());
        textView3.setText(Float.toString(utils.getTMP()) + "°C");
        textView5.setText("~" + Integer.toString(utils.getPOP()) + "%");
        textView7.setText("~" + Float.toString(utils.getPCP()) + "mm");

        // 날씨 세부 정보 버튼
        weatherButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("weatherActivity", weatherStr);
                Intent moveWtr = new Intent(getApplicationContext(), WeatherActivity.class);
                moveWtr.putExtra("location", location);
                moveWtr.putExtra("weather", weatherStr);
                startActivity(moveWtr);
            }
        });

        // 옷 추천 버튼
        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveClo;
                float tmp = utils.getTMP();
                if (tmp < 8) {
                    moveClo = new Intent(getApplicationContext(), Cloth_rec3.class); // 패딩
                } else if (tmp < 17) {
                    moveClo = new Intent(getApplicationContext(), Cloth_rec1.class); // 니트
                } else if (tmp < 24) {
                    moveClo = new Intent(getApplicationContext(), Cloth_rec2.class); // 맨투맨
                } else {
                    moveClo = new Intent(getApplicationContext(), Cloth_rec4.class); // 반팔
                }
                startActivity(moveClo);
            }
        });

        // 음식 추천 버튼
        imageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveFood;
                Random random = new Random();
                random.setSeed(System.currentTimeMillis());
                int i = random.nextInt(4);
                if (i == 0) {
                    moveFood = new Intent(getApplicationContext(), Food_rec1.class); // 부대찌개
                } else if (i == 1) {
                    moveFood = new Intent(getApplicationContext(), Food_rec2.class); // 설렁탕
                } else if (i == 2) {
                    moveFood = new Intent(getApplicationContext(), Food_rec3.class); // 치킨
                } else {
                    moveFood = new Intent(getApplicationContext(), Food_rec4.class); // 냉면
                }
                startActivity(moveFood);
            }
        });

        // gps버튼
        GPS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}


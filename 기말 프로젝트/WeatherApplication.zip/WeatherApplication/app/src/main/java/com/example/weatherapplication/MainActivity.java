package com.example.weatherapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONException;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class MainActivity extends AppCompatActivity {
    Dialog location_dialog;

    //Spinner editTextA, editTextB, editTextC; // 도, 시/군/구 , 읍/면/동
    String nx, ny;
    String weather = "";

    int second_count = 0;
    int third_count = 0;

    String SelectedFirst = "";
    String SelectedSecond = "";
    String SelectedThird = "";

    ArrayList<String> SecondSelect = new ArrayList<String>();
    ArrayList<String> ThirdSelect = new ArrayList<String>();
    ArrayList<String> result = new ArrayList<String>();

    int RowLast = 0;
    int RowStart = 0;

    private boolean isFristSelected = true;
    private boolean isSecondSelected = true;
    private boolean isThirdSelected = true;

    public static Activity activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.blank);

        com.example.weatherapplication.WeatherData wd = new com.example.weatherapplication.WeatherData();
//        com.example.weatherapplication.Utils utils = new Utils();

        // 도/특별시/광역시
        final String[] FirstSelect = new String[]{"---도/특별시/광역시---", "서울특별시", "대구광역시", "부산광역시", "대전광역시", "인천광역시",
                "광주광역시", "울산광역시", "세종특별자치시", "경기도", "충청북도", "충청남도", "강원도", "경상북도", "경상남도"
                , "전라남도", "전라북도", "제주특별자치도", "이어도"};

        // 초기 화면 -> 다이얼로그 출력해서 지역 값 입력받기
        location_dialog = new Dialog(MainActivity.this);
        location_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        location_dialog.setContentView(R.layout.location_dialog);

        // 다이얼로그 show
        location_dialog.show();

        Spinner spinnerfirst = (Spinner) location_dialog.findViewById(R.id.spinner1);
        ArrayAdapter adapterfirst = new ArrayAdapter(this, android.R.layout.simple_spinner_item, FirstSelect);
        adapterfirst.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerfirst.setAdapter(adapterfirst);

        Spinner spinnersecond = (Spinner) location_dialog.findViewById(R.id.spinner2);
        ArrayAdapter adaptersecond = new ArrayAdapter(spinnerfirst.getContext(), android.R.layout.simple_spinner_item, SecondSelect);
        adaptersecond.setDropDownViewResource(android.R.layout.simple_spinner_item);

        Spinner spinnerthird = (Spinner) location_dialog.findViewById(R.id.spinner3);
        ArrayAdapter adapterthird = new ArrayAdapter(spinnersecond.getContext(), android.R.layout.simple_spinner_item, ThirdSelect);
        adapterthird.setDropDownViewResource(android.R.layout.simple_spinner_item);


//        editTextA = location_dialog.findViewById(R.id.spinner1);
//        editTextB = location_dialog.findViewById(R.id.spinner2);
//        editTextC = location_dialog.findViewById(R.id.spinner3);

        // 도, 특별시, 광역시
        spinnerfirst.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(isFristSelected){
                    isFristSelected = false;
                } else{
                    spinnersecond.setSelection(0);
                    spinnerthird.setAdapter(adapterthird);

                    SelectedFirst = (String)spinnerfirst.getSelectedItem();
                    findLocationFirst(spinnerfirst.getSelectedItem().toString());

                    // 시,군,구 하위 항목 설정
                    spinnersecond.setAdapter(adaptersecond);

                    // 확인용
                    Log.i("second", SecondSelect.toString());
                    isFristSelected = true;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        // 시,군,구
        spinnersecond.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(isSecondSelected) isSecondSelected = false;
                else {
                    SelectedSecond = (String) spinnersecond.getSelectedItem();

                    findLocationSecond((String) spinnersecond.getSelectedItem(), RowStart, RowLast);
                    spinnerthird.setAdapter(adapterthird);
                    isSecondSelected = true;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        // 읍,면,동
        spinnerthird.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(isThirdSelected) isThirdSelected = false;
                else {
                    SelectedThird = (String) spinnerthird.getSelectedItem();

                    findLocationThird((String) spinnerthird.getSelectedItem(), RowStart, RowLast);
                    isThirdSelected = true;
                    isFristSelected = false;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        // 확인 버튼 눌렀을때
        Button OkayBtn = location_dialog.findViewById(R.id.btnLocation);
        OkayBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (SelectedFirst.equals("---도/특별시/광역시---")) {
                    Toast.makeText(getApplicationContext(), "지역을 선택해 주세요.", Toast.LENGTH_LONG).show();
                    return;
                }

                // 좌표값 넣어서 현재 날씨 구하기
                // 에러가 발생하면 에러메세지를 화면에 표시 후 바로 메소드 종료
                new Thread(()->{
                    try {
                        wd.func(nx, ny);
                        weather = wd.getWeather();
                        Log.i("resultCode", wd.getResultCode());
                        if (!wd.getResultCode().equals("00")) {
                            /*
                            에러메세지 출력
                             */
                            return;
                        }
                        else {
                            Log.i("location", SelectedSecond);
                            Log.i("weather", weather);

                            location_dialog.dismiss();
                            Intent move = new Intent(getApplicationContext(), weather_rec.class);
                            move.putExtra("location", SelectedFirst + " " + SelectedSecond + " " + SelectedThird); // 지역 이름. 비어있을 경우 다른 문자열을 저장할 코드 필요
                            move.putExtra("weather", wd.getWeather());
                            startActivity(move);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    } catch (RuntimeException e) {
                        e.printStackTrace();
                    }
                }).start();


            }
        });
    }

    private void findLocationFirst(String A) {
        try{
            InputStream inputStream =getBaseContext().getResources().getAssets().open("location.xls");
            // excel file
            Workbook wb = Workbook.getWorkbook(inputStream);

            ArrayList<String> result = new ArrayList<String>();
            second_count = 0;

            // 엑셀 파일이 있다면
            if(wb != null){
                // 시트 불러오기

                Sheet sheet = wb.getSheet(0);
                Log.i("Main", "시트 불러옴");


                // 좌표 찾기
                if(sheet != null){
                    int rowIndexStart = 1;
                    int rowTotal = 3789;
                    Log.i("Main", "colTotal------rowIndexStart------rowTotal");

                    for (int row = rowIndexStart; row<rowTotal; row++){

                        String contentsA = sheet.getCell(0, row).getContents();
                        String contentsB = sheet.getCell(1, row).getContents();

                        if(contentsA.equals(A)){
                            if(RowStart==0) RowStart = row;
                            if(contentsB.equals(null)) result.add("");
                            else result.add(contentsB);
                            RowLast = row;
                        }
                    }
                    for(String a: result){
                        if(!SecondSelect.contains(a)) SecondSelect.add(second_count++, a);
                        Log.i("result", a);
                    }
                    Log.i("secondselect", SecondSelect.toString());
                    Log.i("row", "RowStart " + RowStart + " RowLast "+RowLast);
                    result.clear();
                }

            }
        } catch (IOException | BiffException e) {
            e.printStackTrace();
        }
    }


    private void findLocationSecond(String B, int rowStart, int rowLast) {
        try{
            InputStream inputStream =getBaseContext().getResources().getAssets().open("location.xls");
            // excel file
            Workbook wb = Workbook.getWorkbook(inputStream);

            ArrayList<String> result = new ArrayList<String>();
            third_count = 0;

            // 엑셀 파일이 있다면
            if(wb != null){
                // 시트 불러오기

                Sheet sheet = wb.getSheet(0);
                Log.i("Main", "시트 불러옴");

                // 좌표 찾기
                if(sheet != null){
                    Log.i("Mainsec", "colTotal------rowIndexStart------rowTotal");

                    for (int row = rowStart; row<=rowLast; row++){

                        String contentsB = sheet.getCell(1, row).getContents();
                        String contentsC = sheet.getCell(2, row).getContents();

                        if(contentsB.equals(B)){
                            if(row == rowStart) {
                                RowStart = row;
                            }
                            if(contentsC.equals(null)) result.add("");
                            else result.add(contentsC);
                            RowLast = row;
                        }
                    }
                    for(String a: result){
                        if(!ThirdSelect.contains(a)) ThirdSelect.add(third_count++, a);
                        Log.i("result", a);
                    }
                    Log.i("Thirdselect", ThirdSelect.toString());
                    result.clear();
                }

            }
        } catch (IOException | BiffException e) {
            e.printStackTrace();
        }
    }

    private void findLocationThird(String C, int rowStart, int rowLast) {
        try{
            InputStream inputStream =getBaseContext().getResources().getAssets().open("location.xls");
            // excel file
            Workbook wb = Workbook.getWorkbook(inputStream);
            // 엑셀 파일이 있다면
            if(wb != null){
                // 시트 불러오기

                Sheet sheet = wb.getSheet(0);
                Log.i("Mainthird", "시트 불러옴");


                // 좌표 찾기
                if(sheet != null){
                    Log.i("Main", "colTotal------rowIndexStart------rowTotal");

                    for (int row = rowStart; row<=rowLast; row++){

                        String contentsC = sheet.getCell(2, row).getContents();

                        if(contentsC.equals(C)){
                            nx = sheet.getCell(3, row).getContents();
                            ny = sheet.getCell(4, row).getContents();
                            break;
                        }
                    }
                }
            }
        } catch (IOException | BiffException e) {
            e.printStackTrace();
        }
        RowStart = 0;
        RowLast = 0;
        SecondSelect.clear();
        ThirdSelect.clear();
        Log.i("Check", "nx : "+ nx + " ny: " + ny);

    }

}


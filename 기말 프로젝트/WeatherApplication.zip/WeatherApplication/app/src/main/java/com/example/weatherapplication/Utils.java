package com.example.weatherapplication;

// 받은 데이터를 자료형 변환 후 저장할 구조체
public class Utils {
    float TMP = 0.0f; // 1시간 기온
    float TMN = 0.0f; // 최저 기온
    float TMX = 0.0f; // 최고 기온
    int POP = 0; // 강수 확률
    int PCP = 0; // 1시간 강수량
    String SKY = ""; // 하늘 상태
    String PTY = ""; // 강수 형태

    public void set(String TMP, String TMN, String TMX, String POP, String PCP, String SKY, String PTY) {
        this.TMP = Float.parseFloat(TMP);
        this.TMN = Float.parseFloat(TMN);
        this.TMX = Float.parseFloat(TMX);
        this.POP = Integer.parseInt(POP);

        if (PCP.equals("강수없음")) {
            this.PCP = 0;
        } else {
            this.PCP = Integer.parseInt(PCP);
        }

        int SKY_int = Integer.parseInt(SKY);
        if (SKY_int == 1) {
            this.SKY = "맑음";
        } else if (SKY_int == 3) {
            this.SKY = "구름 많음";
        } else {
            this.SKY = "흐림";
        }

        if (PTY == "1") {
            this.PTY = "비";
        } else if (PTY == "2") {
            this.PTY = "비/눈";
        } else if (PTY == "3") {
            this.PTY = "눈";
        } else if (PTY == "4") {
            this.PTY = "소나기";
        } else {
            this.PTY = "없음";
        }
    }

    public Utils() {}
    public Utils(String weather) {
        String data[] = weather.split(",");
        set(data[0],data[1],data[2],data[3],data[4],data[5],data[6]);
    }

    public float getTMP(){
        return TMP;
    }

    public float getTMN() {
        return TMN;
    }

    public float getTMX() {
        return TMX;
    }

    public int getPOP() {
        return POP;
    }

    public int getPCP() {
        return PCP;
    }

    public String getSKY() {
        return SKY;
    }

    public String getPTY() {
        return PTY;
    }
}

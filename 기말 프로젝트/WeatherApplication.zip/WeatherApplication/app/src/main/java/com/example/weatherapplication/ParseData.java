package com.example.weatherapplication;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ParseData {
    String TMP = ""; // 1시간 기온
    String TMN = ""; // 최저 기온
    String TMX = ""; // 최고 기온
    String POP = ""; // 강수 확률
    String PCP = ""; // 1시간 강수량
    String SKY = ""; // 하늘 상태
    String PTY = ""; // 강수 형태

    String currentTime; // 현재 시간
    int cur;

    public ParseData() {
        // 현재 시간 대 (분 단위는 00)
        long mNow = System.currentTimeMillis();
        Date mReDate = new Date(mNow);

        SimpleDateFormat mFormatTime = new SimpleDateFormat("HH00");
        currentTime = mFormatTime.format(mReDate);

        cur = (Integer.parseInt(currentTime) + 100) % 2400;
        Log.i("current time", currentTime);
    }

    public String parse(String result, int state) throws JSONException {
        // response 키를 가지고 데이터를 파싱
        JSONObject jsonObj_1 = new JSONObject(result);
        String response = jsonObj_1.getString("response");

        // response 로 부터 body 찾기
        JSONObject jsonObj_2 = new JSONObject(response);
        String body = jsonObj_2.getString("body");

        // body 로 부터 head 찾기
        JSONObject jsonObj_r1 = new JSONObject(response);
        String header = jsonObj_r1.getString("header");

        // resultCode 찾기. 정상적으로 받아오지 못했다면 바로 오류코드를 리턴
        JSONObject jsonObj_r2 = new JSONObject(header);
        String resultCode = jsonObj_r2.getString("resultCode");
        if (!resultCode.equals("00")) {
            Log.i("check resultCode", resultCode);
            return resultCode;
        }

        // body 로 부터 items 찾기
        JSONObject jsonObj_3 = new JSONObject(body);
        String items = jsonObj_3.getString("items");
        //Log.i("ITEMS", items);

        // items로 부터 itemlist 를 받기
        JSONObject jsonObj_4 = new JSONObject(items);
        JSONArray jsonArray = jsonObj_4.getJSONArray("item");
        //Log.i("item", String.valueOf(jsonArray));

        // 날씨 값 저장
        for (int i = 0; i < jsonArray.length(); i++) {
            jsonObj_4 = jsonArray.getJSONObject(i);
            String fcstValue = jsonObj_4.getString("fcstValue");
            String fcstTime = jsonObj_4.getString("fcstTime");
            String category = jsonObj_4.getString("category");

            int Int_fcstTime = Integer.parseInt(fcstTime);

            if(state == 1){
                // 최고기온 최저기온 -> 전날 11시 예보에서 얻을 수 있음
                if (category.equals("TMN")) {
                    TMN = fcstValue;    // 최저기온
                }
                else if (category.equals("TMX")) {
                    TMX = fcstValue;
                }
            }

            else if(state == 0 && Int_fcstTime == cur){
                // 현재 날짜에서 가져오는 값들 - 현재 기온, 강수 확률, 강수량, 하늘 상태, 강수 형태
                if (category.equals("TMP")) {
                    TMP = fcstValue;
                }
                else if (category.equals("POP")) {
                    POP = fcstValue;
                }
                else if (category.equals("PCP")) {
                    PCP = fcstValue;
                }
                else if (category.equals("SKY")) {
                    SKY = fcstValue;
                }
                else if (category.equals("PTY")) {
                    PTY = fcstValue;
                }
            }

        }
        return "00";
    }

    public String getTMP(){
        return TMP;
    }

    public String getTMN() {
        return TMN;
    }

    public String getTMX() {
        return TMX;
    }

    public String getPOP() {
        return POP;
    }

    public String getPCP() {
        return PCP;
    }

    public String getSKY() {
        return SKY;
    }

    public String getPTY() {
        return PTY;
    }
}
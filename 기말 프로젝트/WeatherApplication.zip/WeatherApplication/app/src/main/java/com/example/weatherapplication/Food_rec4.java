package com.example.weatherapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Food_rec4 extends AppCompatActivity {

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recfood_04);

        // 뒤로가기 버튼
        ImageButton exit1 = (ImageButton) findViewById(R.id.imageButton);
        exit1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                onBackPressed();
                //finish();
            }
        });
    }
}
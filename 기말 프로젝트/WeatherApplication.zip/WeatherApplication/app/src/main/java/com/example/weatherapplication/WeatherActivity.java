package com.example.weatherapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class WeatherActivity extends AppCompatActivity {

    TextView region02; // 지역 이름 텍스트뷰
    TextView temp02; // 현재 기온 텍스트뷰
    TextView ht02; // 최고 기온 텍스트뷰
    TextView lt02; // 최저 기온 텍스트뷰
    TextView rainpro02; // 강수 확률 텍스트뷰
    TextView hymeter02; // 강수량 텍스트뷰
    ImageButton imageButton; // 뒤로가기 버튼

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sulmyung);

        // 뷰, 버튼 연결
        region02 = findViewById(R.id.region02);
        temp02 = findViewById(R.id.temp02);
        ht02 = findViewById(R.id.ht02);
        lt02 = findViewById(R.id.lt02);
        rainpro02 = findViewById(R.id.rainpro02);
        hymeter02 = findViewById(R.id.hymeter02);
        imageButton = findViewById(R.id.imageButton);

        // 인텐트로 지역과 날씨 정보 받아옴
        Intent get = getIntent();
        String location = get.getStringExtra("location");
        String weatherStr = get.getStringExtra("weather");
        Utils utils = new Utils(weatherStr);
        Log.i("received",weatherStr);

        // 텍스트뷰 설정
        region02.setText(location);
        temp02.setText(Float.toString(utils.getTMP()) + "°C");
        ht02.setText(Float.toString(utils.getTMX()) + "°C");
        lt02.setText(Float.toString(utils.getTMN()) + "°C");
        rainpro02.setText("~" + Integer.toString(utils.getPOP()) + "%");
        hymeter02.setText("~" + Integer.toString(utils.getPCP()) + "mm");

        // 뒤로가기 버튼
        imageButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                onBackPressed();
            }
        });
    }
}
